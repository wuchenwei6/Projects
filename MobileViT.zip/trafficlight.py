import time


# 交通灯状态
class TrafficLight:
    def __init__(self, id):
        self.id = id
        self.color = "Red"
        self.green_time = 10
        self.yellow_time = 3
        self.red_time = 10
        self.is_normal = True

    def set_color(self, color):
        self.color = color

    def get_color(self):
        return self.color


# 车辆状态
class CarStatus:
    def __init__(self):
        self.count = 0
        self.stay_time = 0
        self.queue_distance = 0.0


# 行人状态
class PedestrianStatus:
    def __init__(self):
        self.count = 0
        self.is_normal = True
        self.green_time = 10
        self.yellow_time = 3
        self.red_time = 10


# 道路状态
class RoadStatus:
    def __init__(self):
        self.car_count = 0
        self.pedestrian_count = 0


# 十字路口
class Intersection:
    def __init__(self):
        # 初始化四个车辆信号灯和八个行人信号灯
        self.car_lights = [TrafficLight(i) for i in range(4)]
        self.pedestrian_lights = [PedestrianStatus() for _ in range(8)]
        self.car_status = CarStatus()
        self.pedestrian_status = PedestrianStatus()

        # 初始化四个车辆道路和四个行人道路
        self.car_roads = {'U': RoadStatus(), 'D': RoadStatus(), 'L': RoadStatus(), 'R': RoadStatus()}
        self.pedestrian_roads = {'u': RoadStatus(), 'd': RoadStatus(), 'l': RoadStatus(), 'r': RoadStatus()}

    def set_car_light_color(self, light_id, color):
        self.car_lights[light_id].set_color(color)

    def set_pedestrian_light_color(self, light_id, color):
        self.pedestrian_lights[light_id].color = color

    def set_car_status(self, count, stay_time, queue_distance):
        self.car_status.count = count
        self.car_status.stay_time = stay_time
        self.car_status.queue_distance = queue_distance

    def set_pedestrian_status(self, count, is_normal, green_time, yellow_time, red_time):
        self.pedestrian_status.count = count
        self.pedestrian_status.is_normal = is_normal
        self.pedestrian_status.green_time = green_time
        self.pedestrian_status.yellow_time = yellow_time
        self.pedestrian_status.red_time = red_time

    def update_car_road_status(self, road, car_count, pedestrian_count):
        self.car_roads[road].car_count = car_count
        self.car_roads[road].pedestrian_count = pedestrian_count

    def update_pedestrian_road_status(self, road, car_count, pedestrian_count):
        self.pedestrian_roads[road].car_count = car_count
        self.pedestrian_roads[road].pedestrian_count = pedestrian_count


# 交通信号控制箱
class TrafficSignalController:
    def __init__(self, intersection):
        self.intersection = intersection

    def init(self):
        for light in self.intersection.car_lights:
            light.set_color("Red")
        for light in self.intersection.pedestrian_lights:
            light.color = "Red"

    def image_recognition(self, image_data):
        # 模拟图像识别，返回车辆个数和行人个数
        return 15, 5

    def is_congested(self, car_count, pedestrian_count, queue_distance):
        # 判断是否拥堵
        return car_count > 10 or pedestrian_count > 10 or queue_distance > 5.0

    def get_extend_time(self, car_count, pedestrian_count, queue_distance):
        # 确定延长时间
        return 5

    def set_light_color(self, light_id, duration, color):
        # 设置信号灯颜色和持续时间
        self.intersection.set_car_light_color(light_id, color)
        time.sleep(duration)

    def normal_mode(self):
        while True:
            car_count, pedestrian_count = self.image_recognition(None)
            queue_distance = 2.0  # 模拟排队距离
            if self.is_congested(car_count, pedestrian_count, queue_distance):
                extend_time = self.get_extend_time(car_count, pedestrian_count, queue_distance)
            else:
                extend_time = 0

            # 更新道路状态
            for road in ['U', 'D', 'L', 'R']:
                car_count, pedestrian_count = self.image_recognition(None)
                self.intersection.update_car_road_status(road, car_count, pedestrian_count)

            for road in ['u', 'd', 'l', 'r']:
                car_count, pedestrian_count = self.image_recognition(None)
                self.intersection.update_pedestrian_road_status(road, car_count, pedestrian_count)

            # 输出信号灯变化逻辑
            print(f"U车辆道路车辆数量: {self.intersection.car_roads['U'].car_count}")
            print("信号灯变化逻辑：")
            # U1D1u1u2d1d2上下直行方向走

            print(f"U1D1车辆道路和人行道u1d2 u2d1 ：信号灯{0} - 绿灯持续10秒")
            self.set_light_color(0, 10 + extend_time, "Green")
            print(f"U1D1车辆道路和人行道u2d1 u1d2：信号灯{0} - 黄灯持续3秒")
            self.set_light_color(0, 3 + extend_time, "Yellow")
            print(f"U1D1车辆道路和人行道u2d1 u1d2：信号灯{0} - 红灯持续10秒")
            self.set_light_color(0, 10 + extend_time, "Red")

            # U2D2上下左转方向走

            print(f"U2D2车辆左转道路：信号灯{1} - 绿灯持续10秒")
            self.set_light_color(1, 10 + extend_time, "Green")
            print(f"U2D2车辆左转道路：信号灯{1} - 黄灯持续3秒")
            self.set_light_color(1, 3 + extend_time, "Yellow")
            print(f"U2D2车辆左转道路：信号灯{1} - 红灯持续10秒")
            self.set_light_color(1, 10 + extend_time, "Red")

            # L1 R1 l1 l2 r1 r2左右直行方向走

            print(f"L1R1车辆道路和l1r1 l2r2人行道：信号灯{2} - 绿灯持续10秒")
            self.set_light_color(2, 10 + extend_time, "Green")
            print(f"L1R1车辆道路和l1r1 l2r2人行道：信号灯{2} - 黄灯持续3秒")
            self.set_light_color(2, 3 + extend_time, "Yellow")
            print(f"L1R1车辆道路和l1r1 l2r2人行道：信号灯{2} - 红灯持续10秒")
            self.set_light_color(2, 10 + extend_time, "Red")

            # L2R2左右左转方向走

            print(f"L2R2车辆左转道路：信号灯{3} - 绿灯持续10秒")
            self.set_light_color(3, 10 + extend_time, "Green")
            print(f"L2R2车辆左转道路：信号灯{3} - 黄灯持续3秒")
            self.set_light_color(3, 3 + extend_time, "Yellow")
            print(f"L2R2车辆左转道路：信号灯{3} - 红灯持续10秒")
            self.set_light_color(3, 10 + extend_time, "Red")


if __name__ == "__main__":
    intersection = Intersection()
    controller = TrafficSignalController(intersection)
    controller.init()
    controller.normal_mode()
